THE .sql SHOULD BE EXECUTED AS FOLLOWING ORDER(Other wise some conflicts may occur since the tables have relations)

    1) Build_the_database.sql
    2) Insert_data.sql
    3) Indexes.sql
    4) Store_procedures.sql
    5) Customer_Queries.sql
    6) Dealer_Queries.sql
    7) Delivery_people_Queries.sql

